# FoodDeliveryWeb
This is basic Food Delivery Website as my project.
