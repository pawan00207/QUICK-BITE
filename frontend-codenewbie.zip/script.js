document.addEventListener("DOMContentLoaded", function () {
    // Load Cart from Local Storage
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let totalPrice = 0;
    updateCart();

    // Contact Form Validation
    document.getElementById("contactForm").addEventListener("submit", function (e) {
        e.preventDefault();
        let name = document.getElementById("name").value.trim();
        let email = document.getElementById("email").value.trim();
        let message = document.getElementById("message").value.trim();

        if (name === "" || email === "" || message === "") {
            alert("All fields are required!");
            return;
        }

        if (!email.includes("@") || !email.includes(".")) {
            alert("Please enter a valid email address!");
            return;
        }

        alert("Thank you for contacting us! We will get back to you soon.");
        this.reset();
    });

    // Cart Functionality
    document.querySelectorAll(".add-to-cart").forEach(button => {
        button.addEventListener("click", function () {
            let serviceName = this.parentElement.getAttribute("data-name");
            cart.push(serviceName);
            updateCart();
        });
    });

    function updateCart() {
        let cartList = document.getElementById("cart");
        cartList.innerHTML = "";
        cart.forEach((item, index) => {
            let li = document.createElement("li");
            li.textContent = item;
            let removeBtn = document.createElement("button");
            removeBtn.textContent = "Remove";
            removeBtn.classList.add("remove-item");
            removeBtn.setAttribute("data-index", index);
            li.appendChild(removeBtn);
            cartList.appendChild(li);
        });
        totalPrice = cart.length * 10; // Assuming each service costs $10
        document.getElementById("totalPrice").textContent = "$" + totalPrice;
        localStorage.setItem("cart", JSON.stringify(cart));
    }

    document.getElementById("cart").addEventListener("click", function (e) {
        if (e.target.classList.contains("remove-item")) {
            let index = e.target.getAttribute("data-index");
            cart.splice(index, 1);
            updateCart();
        }
    });

    // Search Box Functionality
    document.getElementById("searchBox").addEventListener("input", function () {
        let searchText = this.value.toLowerCase();
        document.querySelectorAll(".box").forEach(box => {
            let serviceName = box.getAttribute("data-name").toLowerCase();
            if (serviceName.includes(searchText)) {
                box.style.display = "block";
            } else {
                box.style.display = "none";
            }
        });
    });

    // Order Now Button
    document.getElementById("orderNowBtn").addEventListener("click", function () {
        if (cart.length === 0) {
            alert("Your cart is empty! Please add some services before ordering.");
        } else {
            alert("Your order has been placed successfully!");
            cart = [];
            updateCart();
        }
    });
});
